import React, { useState } from "react";

const forestGreen = "#2e4631";
const mossGreen = "#6b8e23";
const earthBrown = "#8b6f4e";
const stoneGray = "#e5e5e5";
const white = "#fff";

const menus = [
  "Novo projeto",
  "Editar projeto",
  "Excluir projeto",
];

export default function TopbarProjetos() {
  const [ativo, setAtivo] = useState(menus[0]); // Começa com "Equações"

  return (
    <header style={topbarStyle}>
      <nav style={navStyle}>
        {menus.map((menu) => (
          <NavButton
            key={menu}
            ativo={ativo === menu}
            onClick={() => setAtivo(menu)}
          >
            {menu}
          </NavButton>
        ))}
      </nav>
      <div style={userAreaStyle}>
        <span style={userIconStyle}>👤</span>
        <span style={userNameStyle}>Usuário</span>
        <button style={logoutBtnStyle} onClick={() => window.location.href = "/login"}>Sair</button>
      </div>
    </header>
  );
}

// --- COMPONENTE BOTÃO DE NAVEGAÇÃO ---
function NavButton({ ativo, children, ...props }) {
  return (
    <button
      style={{
        ...navBtnStyle,
        ...(ativo
          ? {
              background: mossGreen,
              color: white,
              boxShadow: "0 3px 9px #6b8e2318",
              opacity: 1,
            }
          : {})
      }}
      {...props}
    >
      {children}
    </button>
  );
}

// --- ESTILOS ---

const topbarStyle = {
  fontFamily: "Calibri, Arial, sans-serif",
  height: 58,
  background: forestGreen,
  color: white,
  display: "flex",
  alignItems: "center",
  justifyContent: "space-between",
  paddingLeft: 200,
  paddingRight: 36,
  position: "fixed",
  left: 0,
  top: 0,
  width: "100%",
  zIndex: 1,
  boxShadow: "0 2px 14px #2e46311a",
  borderBottomLeftRadius: 16,
};

const navStyle = {
  display: "flex",
  gap: 18,
  alignItems: "center",
};

const navBtnStyle = {
  background: stoneGray,
  color: forestGreen,
  border: "none",
  borderRadius: 7,
  fontFamily: "Calibri, Arial, sans-serif",
  fontWeight: 700,
  fontSize: 16,
  letterSpacing: 1,
  cursor: "pointer",
  padding: "7px 19px",
  boxShadow: "0 2px 7px #2e463115",
  transition: "background 0.13s, color 0.13s, box-shadow 0.15s, opacity 0.13s",
  opacity: 0.95,
  userSelect: "none",
  outline: "none",
  marginRight: 1,
};

const userAreaStyle = {
  display: "flex",
  alignItems: "center",
  gap: 10,
  background: mossGreen,
  borderRadius: 9,
  padding: "7px 18px",
  fontWeight: 600,
};

const userIconStyle = {
  fontSize: 18,
  marginRight: 3,
};

const userNameStyle = {
  color: white,
  fontWeight: 600,
  fontSize: 16,
  fontFamily: "Calibri, Arial, sans-serif"
};


const logoutBtnStyle = {
  background: stoneGray,
  color: forestGreen,
  border: "none",
  borderRadius: 5,
  fontSize: 15,
  fontWeight: 700,
  padding: "5px 15px",
  marginLeft: 16,
  cursor: "pointer",
  transition: "background 0.15s, color 0.15s",
  fontFamily: "Calibri, Arial, sans-serif",
  boxShadow: "0 1px 4px #2e46311a"
};
