// TopbarMapajsx
import React from 'react';

export default function TopbarMapa() {
  const onEdit = () => {
    alert('Modo Edição ativado');
  };
  const onLayout = () => {
    alert('Configurar Layout');
  };
  const onExport = () => {
    alert('Exportar relatórios e mapas');
  };

  return (
    <div
      style={{
        height: 50,
        backgroundColor: '#333',
        color: '#fff',
        display: 'flex',
        alignItems: 'center',
        padding: '0 16px',
        gap: 16,
      }}
    >
      <button onClick={onEdit}>Edição</button>
      <button onClick={onLayout}>Layout</button>
      <button onClick={onExport}>Exportar</button>
    </div>
  );
}
