export default function Dados() {
  return <h1>Dados funcionando!</h1>;
}