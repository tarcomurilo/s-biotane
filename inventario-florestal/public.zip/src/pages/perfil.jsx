export default function Perfil() {
  return <h1>Perfil funcionando!</h1>;
}