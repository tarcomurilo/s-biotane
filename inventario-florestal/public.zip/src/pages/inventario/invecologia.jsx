export default function InvEcologia() {
  return (
    <div>
      <h1>Projeto — Ecologia</h1>
      {/* aqui fica o conteúdo da sub-página Projeto */}
    </div>
  );
}
