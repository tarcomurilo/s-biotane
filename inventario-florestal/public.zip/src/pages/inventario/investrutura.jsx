export default function InvEstrutura() {
  return (
    <div>
      <h1>Projeto — Estrutura</h1>
      {/* aqui fica o conteúdo da sub-página Projeto */}
    </div>
  );
}
