// src/pages/inventario/invproj.jsx
// Sub-página: Projeto — Detalhes e seleção de contexto (Talhões/Estratos)
// Regras solicitadas:
// - Estratos: múltiplos podem estar ativos; toggle por item.
// - Não permitir desativar o ÚNICO estrato ativo (sempre manter >= 1 quando houver estratos).
// - Ao ATIVAR um talhão: ativar automaticamente o PRIMEIRO estrato desse talhão (e desativar os demais desse talhão).
// - Ao DESATIVAR um talhão: todos os estratos desse talhão ficam desativados.
// - Calibri; design dos cards/botões mantido.

import React, { useEffect, useMemo, useState } from "react";

// --- Utils ---
const safeParse = (v) => { try { return JSON.parse(v || "null"); } catch { return null; } };
const toISODate = (d) => {
  if (!d) return "";
  const dt = new Date(d);
  if (Number.isNaN(dt.getTime())) return "";
  const mm = String(dt.getMonth() + 1).padStart(2, "0");
  const dd = String(dt.getDate()).padStart(2, "0");
  return `${dt.getFullYear()}-${mm}-${dd}`;
};
const fromDateInput = (v) => (v ? new Date(v).toISOString() : "");

export default function InvProj() {
  // Snapshot do projeto
  const [project, setProject] = useState(() => safeParse(sessionStorage.getItem("activeProject")));
  const projectId = project?.id;

  // Form
  const [form, setForm] = useState(() => ({
    codigo: project?.codigo || project?.id || "",
    nome: project?.nome || "",
    dataInicio: toISODate(project?.dataAbertura || project?.dataInicio || ""),
    dataEntrega: toISODate(project?.dataEntrega || ""),
    valor: project?.valorTotal ?? "",
  }));
  useEffect(() => {
    if (!project) return;
    setForm({
      codigo: project?.codigo || project?.id || "",
      nome: project?.nome || "",
      dataInicio: toISODate(project?.dataAbertura || project?.dataInicio || ""),
      dataEntrega: toISODate(project?.dataEntrega || ""),
      valor: project?.valorTotal ?? "",
    });
  }, [project]);

  const onChange = (k, v) => setForm((s) => ({ ...s, [k]: v }));
  const salvarLocal = () => {
    if (!project) return;
    const next = {
      ...project,
      codigo: form.codigo?.trim() || project.codigo,
      nome: form.nome?.trim() || project.nome,
      dataAbertura: form.dataInicio ? fromDateInput(form.dataInicio) : project.dataAbertura,
      dataEntrega: form.dataEntrega ? fromDateInput(form.dataEntrega) : project.dataEntrega,
      valorTotal: form.valor === "" ? project.valorTotal : Number(form.valor),
      updatedAt: new Date().toISOString(),
    };
    setProject(next);
    sessionStorage.setItem("activeProject", JSON.stringify(next));
    // TODO: sincronizar com backend (PATCH /projetos/:id)
  };

  // Talhões
  const [talhoes, setTalhoes] = useState(() => {
    const map = safeParse(sessionStorage.getItem("talhoes"));
    return Array.isArray(map?.[projectId]) ? map[projectId] : [];
  });
  useEffect(() => {
    const map = safeParse(sessionStorage.getItem("talhoes"));
    setTalhoes(Array.isArray(map?.[projectId]) ? map[projectId] : []);
  }, [projectId]);

  const activeTalhaoId = useMemo(() => talhoes.find((t) => t.ativo)?.id || "", [talhoes]);

  const toggleTalhao = (id) => {
    // Se clicar no mesmo talhão ativo -> DESATIVAR esse talhão e desativar TODOS seus estratos
    const current = talhoes.find(t => t.id === id);
    const isActive = !!current?.ativo;
    let nextTalhoes;
    if (isActive) {
      // desativa somente o clicado (mantém os demais como estão)
      nextTalhoes = talhoes.map(t => t.id === id ? { ...t, ativo: false } : t);
      // desativa todos os estratos desse talhão
      const estratosMap = safeParse(sessionStorage.getItem("estratos")) || {};
      const list = Array.isArray(estratosMap[id]) ? estratosMap[id] : [];
      estratosMap[id] = list.map(e => ({ ...e, ativo: false }));
      sessionStorage.setItem("estratos", JSON.stringify(estratosMap));
      sessionStorage.setItem("activeEstratoIds", JSON.stringify([]));
      sessionStorage.setItem("activeEstratoId", "");
    } else {
      // ativar este talhão (exclusivo) e desativar os outros
      nextTalhoes = talhoes.map(t => ({ ...t, ativo: t.id === id }));
      // ao ativar, ligar o PRIMEIRO estrato desse talhão e desligar os demais
      const estratosMap = safeParse(sessionStorage.getItem("estratos")) || {};
      const list = Array.isArray(estratosMap[id]) ? estratosMap[id] : [];
      if (list.length > 0) {
        const updated = list.map((e, idx) => ({ ...e, ativo: idx === 0 }));
        estratosMap[id] = updated;
        sessionStorage.setItem("estratos", JSON.stringify(estratosMap));
        const actives = updated.filter(e => e.ativo).map(e => e.id);
        sessionStorage.setItem("activeEstratoIds", JSON.stringify(actives));
        sessionStorage.setItem("activeEstratoId", actives[0] || "");
      } else {
        // sem estratos para este talhão
        sessionStorage.setItem("activeEstratoIds", JSON.stringify([]));
        sessionStorage.setItem("activeEstratoId", "");
      }
    }
    setTalhoes(nextTalhoes);
    const map = safeParse(sessionStorage.getItem("talhoes")) || {};
    map[projectId] = nextTalhoes;
    sessionStorage.setItem("talhoes", JSON.stringify(map));
    sessionStorage.setItem("activeTalhaoId", nextTalhoes.find(t => t.ativo)?.id || "");
  };

  // Estratos (dependem do talhão ativo)
  const [estratos, setEstratos] = useState(() => {
    const map = safeParse(sessionStorage.getItem("estratos"));
    return Array.isArray(map?.[activeTalhaoId]) ? map[activeTalhaoId] : [];
  });
  useEffect(() => {
    const map = safeParse(sessionStorage.getItem("estratos"));
    setEstratos(Array.isArray(map?.[activeTalhaoId]) ? map[activeTalhaoId] : []);
  }, [activeTalhaoId]);

  const toggleEstrato = (id) => {
    if (!activeTalhaoId) return;
    const idx = estratos.findIndex(e => e.id === id);
    if (idx < 0) return;

    // Regra: não permitir desativar o ÚNICO ativo
    const activeCount = estratos.filter(e => e.ativo).length;
    const isCurrentlyActive = !!estratos[idx].ativo;
    if (isCurrentlyActive && activeCount === 1) {
      // não faz nada se for o único ativo
      return;
    }

    const next = estratos.map(e => e.id === id ? { ...e, ativo: !e.ativo } : e);
    setEstratos(next);

    const estratosMap = safeParse(sessionStorage.getItem("estratos")) || {};
    estratosMap[activeTalhaoId] = next;
    sessionStorage.setItem("estratos", JSON.stringify(estratosMap));

    const actives = next.filter(e => e.ativo).map(e => e.id);
    sessionStorage.setItem("activeEstratoIds", JSON.stringify(actives));
    sessionStorage.setItem("activeEstratoId", actives[0] || "");
  };

  // --- Edição inline (nomes e tipologia) ---
  const renameTalhao = (id, nome) => {
    if (!projectId) return;
    const next = talhoes.map(t => t.id === id ? { ...t, nome } : t);
    setTalhoes(next);
    const map = safeParse(sessionStorage.getItem("talhoes")) || {};
    map[projectId] = next;
    sessionStorage.setItem("talhoes", JSON.stringify(map));
  };

  const updateEstratoField = (id, field, value) => {
    if (!activeTalhaoId) return;
    const next = estratos.map(e => e.id === id ? { ...e, [field]: value } : e);
    setEstratos(next);
    const estratosMap = safeParse(sessionStorage.getItem("estratos")) || {};
    estratosMap[activeTalhaoId] = next;
    sessionStorage.setItem("estratos", JSON.stringify(estratosMap));
  };

  if (!project) {
    return (
      <div style={{ padding: 8, fontFamily: "Calibri, Arial, sans-serif" }}>
        <h2>Projeto ativo não definido</h2>
        <div style={{ fontSize: 13 }}>O bootstrap deve preencher <code>sessionStorage.activeProject</code>.</div>
      </div>
    );
  }

  return (
    <div style={{ display: "grid", gap: 24, paddingTop: 4, fontFamily: "Calibri, Arial, sans-serif" }}>
      {/* Dados do Projeto */}
      <section style={card}>
        <h2 style={h2}>Dados do Projeto</h2>
        <div style={grid3}>
          <Field label="Código do Projeto">
            <input style={input} value={form.codigo} onChange={(e) => onChange("codigo", e.target.value)} />
          </Field>
          <Field label="Nome do Projeto">
            <input style={input} value={form.nome} onChange={(e) => onChange("nome", e.target.value)} />
          </Field>
          <Field label="Valor">
            <input style={input} inputMode="decimal" placeholder="0,00" value={String(form.valor ?? "")} onChange={(e) => onChange("valor", e.target.value)} />
          </Field>
          <Field label="Data de Início">
            <input style={input} type="date" value={form.dataInicio} onChange={(e) => onChange("dataInicio", e.target.value)} />
          </Field>
          <Field label="Data de Entrega">
            <input style={input} type="date" value={form.dataEntrega} onChange={(e) => onChange("dataEntrega", e.target.value)} />
          </Field>
        </div>
        <div style={{ display: "flex", gap: 8, marginTop: 12 }}>
          <button style={primaryBtn} onClick={salvarLocal}>Salvar</button>
          <span style={{ fontSize: 12, color: "#6b7280" }}>Salva no snapshot local. (TODO: sincronizar no backend)</span>
        </div>
      </section>

      {/* Talhões */}
      <section style={card}>
        <h2 style={h2}>Talhões</h2>
        <div style={{ overflowX: "auto" }}>
          <table style={table}>
            <thead>
              <tr>
                <Th>Nome</Th>
                <Th>Área (ha)</Th>
                <Th>Ativo</Th>
                <Th>Ações</Th>
              </tr>
            </thead>
            <tbody>
              {talhoes.map((t) => (
                <tr key={t.id} style={{...trLine, ...(t.ativo ? activeRow : null)}}>
                  <Td><input style={tableInput} defaultValue={t.nome || ""} onBlur={(e) => renameTalhao(t.id, e.target.value.trim())} placeholder="Nome do talhão" /></Td>
                  <Td>{typeof t.areaHa === "number" ? t.areaHa.toLocaleString("pt-BR") : "-"}</Td>
                  <Td>{t.ativo ? "Sim" : "Não"}</Td>
                  <Td>
                    <button style={smallBtn} onClick={() => toggleTalhao(t.id)}>
                      {t.ativo ? "Desativar" : "Ativar"}
                    </button>
                  </Td>
                </tr>
              ))}
              {talhoes.length === 0 && (
                <tr><Td colSpan={4} style={{ color: "#6b7280" }}>Nenhum talhão cadastrado.</Td></tr>
              )}
            </tbody>
          </table>
        </div>
      </section>

      {/* Estratos (dependem do talhão ativo) */}
      <section style={card}>
        <h2 style={h2}>Estratos {activeTalhaoId ? `— talhão ${activeTalhaoId}` : ""}</h2>
        <div style={{ overflowX: "auto" }}>
          <table style={table}>
            <thead>
              <tr>
                <Th>Nome</Th>
                <Th>Tipologia</Th>
                <Th>Ativo</Th>
                <Th>Ações</Th>
              </tr>
            </thead>
            <tbody>
              {estratos.map((e) => (
                <tr key={e.id} style={{...trLine, ...(e.ativo ? activeRow : null)}}>
                  <Td><input style={tableInput} defaultValue={e.nome || ""} onBlur={(ev) => updateEstratoField(e.id, "nome", ev.target.value.trim())} placeholder="Nome do estrato" /></Td>
                  <Td><input style={tableInput} defaultValue={e.tipologia || ""} onBlur={(ev) => updateEstratoField(e.id, "tipologia", ev.target.value.trim())} placeholder="Tipologia" /></Td>
                  <Td>{e.ativo ? "Sim" : "Não"}</Td>
                  <Td>
                    <button style={smallBtn} onClick={() => toggleEstrato(e.id)}>
                      {e.ativo ? "Desativar" : "Ativar"}
                    </button>
                  </Td>
                </tr>
              ))}
              {estratos.length === 0 && (
                <tr><Td colSpan={4} style={{ color: "#6b7280" }}>Nenhum estrato disponível. {activeTalhaoId ? "Cadastre ou associe estratos ao talhão." : "Ative um talhão para listar."}</Td></tr>
              )}
            </tbody>
          </table>
        </div>
      </section>
    </div>
  );
}

// --- UI primitives ---
const card = {
  background: "#fff",
  borderRadius: 12,
  padding: 16,
  boxShadow: "0 6px 20px rgba(0,0,0,0.08)",
};
const h2 = { margin: 0, marginBottom: 12 };
const grid3 = { display: "grid", gap: 12, gridTemplateColumns: "repeat(3, minmax(0, 1fr))" };
const input = {
  width: "100%",
  border: "1px solid #e5e7eb",
  borderRadius: 8,
  padding: "8px 10px",
  fontFamily: "Calibri, Arial, sans-serif",
  fontSize: 14,
  outline: "none",
};
const tableInput = {
  width: "100%",
  border: "1px solid #e5e7eb",
  borderRadius: 6,
  padding: "6px 8px",
  fontFamily: "Calibri, Arial, sans-serif",
  fontSize: 14,
  outline: "none",
  background: "#fff",
};
const primaryBtn = {
  background: "#6b8e23",
  color: "#fff",
  border: "none",
  borderRadius: 8,
  padding: "8px 16px",
  fontWeight: 700,
  cursor: "pointer",
  boxShadow: "0 2px 7px rgba(0,0,0,0.15)",
  fontFamily: "Calibri, Arial, sans-serif",
};
const smallBtn = {
  background: "#e5e5e5",
  color: "#2e4631",
  border: "none",
  borderRadius: 6,
  padding: "6px 12px",
  cursor: "pointer",
  fontFamily: "Calibri, Arial, sans-serif",
  fontWeight: 700,
};
const smallBtnDisabled = { ...smallBtn, opacity: 0.6, cursor: "default" };
const table = { width: "100%", borderCollapse: "collapse" };
const trLine = { borderBottom: "1px solid #f0f0f0" };
const activeRow = { background: "#e8f5e9" }; // verde claro
function Th({ children }) { return <th style={{ textAlign: "left", padding: "10px 8px", color: "#6b7280", fontSize: 12 }}>{children}</th>; }
function Td({ children, colSpan }) { return <td colSpan={colSpan} style={{ padding: "10px 8px" }}>{children}</td>; }

function Field({ label, children }) {
  return (
    <div style={{ display: "grid", gap: 4 }}>
      <div style={{ fontSize: 12, color: "#6b7280" }}>{label}</div>
      {children}
    </div>
  );
}
