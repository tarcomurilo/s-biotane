export default function InvFitossociologia() {
  return (
    <div>
      <h1>Projeto — Fitossociologia</h1>
      {/* aqui fica o conteúdo da sub-página Projeto */}
    </div>
  );
}
