export default function InvDistribuicao() {
  return (
    <div>
      <h1>Projeto — Distribuição</h1>
      {/* aqui fica o conteúdo da sub-página Projeto */}
    </div>
  );
}
