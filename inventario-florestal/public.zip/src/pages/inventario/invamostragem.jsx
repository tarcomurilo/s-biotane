// src/pages/inventario/invamostragem.jsx
import React, { useEffect, useMemo, useRef, useState } from "react";

const Z_PROB = 1.645; // 90%
const TARGET_ERR = 10; // %

const safeParse = (v) => { try { return JSON.parse(v || "null"); } catch { return null; } };
const fmtNum = (x, d = 2) => (Number.isFinite(x) ? x.toLocaleString("pt-BR", { minimumFractionDigits: d, maximumFractionDigits: d }) : "-");

function getActiveContext() {
  const projeto = safeParse(sessionStorage.getItem("activeProject"));
  const talhoesMap = safeParse(sessionStorage.getItem("talhoes")) || {};
  const estratosMap = safeParse(sessionStorage.getItem("estratos")) || {};
  const talhaoId = sessionStorage.getItem("activeTalhaoId") || "";
  const estrIds = safeParse(sessionStorage.getItem("activeEstratoIds")) || [];
  const talhao = (talhoesMap[projeto?.id] || []).find((t) => t.id === talhaoId) || null;
  const estratos = estratosMap[talhaoId] || [];
  const estratoId = estrIds[0] || (estratos.find((e) => e.ativo)?.id || "");
  const estrato = estratos.find((e) => e.id === estratoId) || null;
  return { projeto, talhaoId, talhao, estratoId, estrato };
}

function keyParcelas(projectId, talhaoId, estratoId) {
  return `${projectId || "_"}:${talhaoId || "_"}:${estratoId || "_"}`;
}

// Estatísticas VISUAIS (90%)
function calcStats(rows) {
  const ativas = rows.filter((r) => r.ativo);
  const n = ativas.length;
  if (n === 0) return { media: 0, cv: 0, erro: 0, nParcelas: 0, nNec: 0 };
  const vols = ativas.map((r) => Number(r.volume) || 0);
  const mean = vols.reduce((a, b) => a + b, 0) / n;
  const variance = vols.reduce((acc, v) => acc + Math.pow(v - mean, 2), 0) / (n - (n > 1 ? 1 : 0));
  const sd = Math.sqrt(variance || 0);
  const cv = mean !== 0 ? (sd / mean) * 100 : 0; // %
  const erro = mean !== 0 ? (Z_PROB * cv) / Math.sqrt(n) : 0; // %
  const nNec = mean !== 0 && cv > 0 ? Math.ceil(Math.pow((Z_PROB * cv) / TARGET_ERR, 2)) : n;
  return { media: mean, cv, erro, nParcelas: n, nNec };
}

// Série do gráfico: erro(n) = z * CV% / sqrt(n)
function genErrorSeries(cv, maxN = 100, z = Z_PROB) {
  const pts = [];
  const N = Math.max(2, Math.min(500, maxN));
  for (let n = 2; n <= N; n++) {
    const err = z * (cv || 0) / Math.sqrt(n);
    pts.push({ n, err });
  }
  return pts;
}

export default function InvAmostragem() {
  const [{ projeto, talhaoId, talhao, estratoId, estrato }, setCtx] = useState(getActiveContext());

  // Parcelas
  const [rows, setRows] = useState(() => {
    const k = keyParcelas(projeto?.id, talhaoId, estratoId);
    const map = safeParse(sessionStorage.getItem("parcelas")) || {};
    const list = Array.isArray(map[k]) ? map[k] : null;
    if (list) return list;
    // Seed visual (todas ativas)
    return Array.from({ length: 12 }).map((_, i) => ({
      id: `P${String(i + 1).padStart(3, "0")}`,
      arvores: 10 + ((i * 3) % 15),
      volume: 8 + (i % 5) * 2 + (i / 10),
      ativo: true,
    }));
  });

  // Recarrega contexto/parcelas quando mudar talhão/estrato
  useEffect(() => {
    const ctx = getActiveContext();
    setCtx(ctx);
    const k = keyParcelas(ctx.projeto?.id, ctx.talhaoId, ctx.estratoId);
    const map = safeParse(sessionStorage.getItem("parcelas")) || {};
    setRows(prev => (Array.isArray(map[k]) ? map[k] : prev));
  }, [talhaoId, estratoId]);

  const persistRows = (next) => {
    const k = keyParcelas(projeto?.id, talhaoId, estratoId);
    const map = safeParse(sessionStorage.getItem("parcelas")) || {};
    map[k] = next;
    sessionStorage.setItem("parcelas", JSON.stringify(map));
  };

  const toggleParcela = (id) => {
    const next = rows.map((r) => (r.id === id ? { ...r, ativo: !r.ativo } : r));
    setRows(next);
    persistRows(next);
  };

  const stats = useMemo(() => calcStats(rows), [rows]);

  // Gráfico (Canvas)
  const canvasRef = useRef(null);
  useEffect(() => {
    const cvs = canvasRef.current;
    if (!cvs) return;
    const dpr = window.devicePixelRatio || 1;
    const cssW = cvs.clientWidth || 480;
    const cssH = cvs.clientHeight || 360;
    cvs.width = Math.floor(cssW * dpr);
    cvs.height = Math.floor(cssH * dpr);

    const ctx = cvs.getContext("2d");
    ctx.setTransform(1, 0, 0, 1, 0, 0);
    ctx.scale(dpr, dpr);
    ctx.clearRect(0, 0, cssW, cssH);
    ctx.font = "12px Calibri, Arial, sans-serif";

    const maxN = Math.max(20, stats.nParcelas * 2, stats.nNec + 5);
    const series = genErrorSeries(stats.cv, maxN);

    // Margens maiores para evitar sobreposição
    const m = { l: 64, r: 16, t: 16, b: 48 };
    const W = cssW - m.l - m.r;
    const H = cssH - m.t - m.b;

    const xMin = 2;
    const xMax = series.length > 0 ? series[series.length - 1].n : 20;
    const yMaxData = Math.max(TARGET_ERR, ...series.map(p => p.err));
    const yMax = Math.ceil((yMaxData * 1.15) / 5) * 5 || 10;

    const x = (n) => m.l + ((n - xMin) / (xMax - xMin)) * W;
    const y = (err) => m.t + (1 - (err / yMax)) * H;

    // Grade horizontal + rótulos Y (sem sobrepor)
    ctx.strokeStyle = "#e5e7eb";
    ctx.lineWidth = 1;
    ctx.textAlign = "right";
    for (let gy = 0; gy <= 5; gy++) {
      const yy = m.t + (gy / 5) * H;
      ctx.beginPath(); ctx.moveTo(m.l, yy); ctx.lineTo(m.l + W, yy); ctx.stroke();
      const val = yMax * (1 - gy / 5);
      ctx.fillStyle = "#6b7280";
      ctx.fillText(`${val.toFixed(0)}%`, m.l - 8, yy + 4);
    }

    // Ticks X
    ctx.fillStyle = "#6b7280";
    ctx.textAlign = "center";
    let stepX = Math.max(1, Math.round((xMax - xMin) / 8));
    if (!Number.isFinite(stepX) || stepX <= 0) stepX = 1;
    for (let nn = xMin; nn <= xMax; nn += stepX) {
      const xx = x(nn);
      ctx.fillText(`${nn}`, xx, m.t + H + 20);
    }

    // Linha alvo (erro máximo admissível)
    ctx.strokeStyle = "#d97706";
    ctx.setLineDash([6, 6]);
    ctx.beginPath(); ctx.moveTo(m.l, y(TARGET_ERR)); ctx.lineTo(m.l + W, y(TARGET_ERR)); ctx.stroke();
    ctx.setLineDash([]);
    ctx.fillStyle = "#d97706";
    ctx.textAlign = "left";
    ctx.fillText(`Erro alvo ${TARGET_ERR}%`, m.l + 8, y(TARGET_ERR) - 6);

    // Linha vertical no n atual
    if (stats.nParcelas > 0) {
      ctx.strokeStyle = "#2563eb";
      ctx.beginPath(); ctx.moveTo(x(stats.nParcelas), m.t); ctx.lineTo(x(stats.nParcelas), m.t + H); ctx.stroke();
      ctx.fillStyle = "#2563eb";
      ctx.textAlign = "left";
      ctx.fillText(`n=${stats.nParcelas}`, x(stats.nParcelas) + 6, m.t + 14);
    }

    // Curva erro(n)
    ctx.strokeStyle = "#10b981";
    ctx.lineWidth = 2;
    ctx.beginPath();
    series.forEach((p, i) => {
      const xx = x(p.n), yy = y(p.err);
      if (i === 0) ctx.moveTo(xx, yy); else ctx.lineTo(xx, yy);
    });
    ctx.stroke();

    // Rótulos dos eixos (afastados)
    ctx.fillStyle = "#111";
    ctx.textAlign = "center";
    ctx.fillText("Número de parcelas (n)", m.l + W / 2, m.t + H + 40);
    ctx.save();
    ctx.translate(m.l - 48, m.t + H / 2);
    ctx.rotate(-Math.PI / 2);
    ctx.fillText("Erro de amostragem (%)", 0, 0);
    ctx.restore();
  }, [stats]);

  return (
    <div style={root}>
      <section style={card}>
        <div style={headerGrid}>
          <Field label="Projeto"><span>{projeto?.nome || "-"}</span></Field>
          <Field label="Talhão"><span>{talhao?.nome || talhaoId || "-"}</span></Field>
          <Field label="Estrato"><span>{estrato?.nome || estratoId || "-"}</span></Field>
        </div>
      </section>

      <section style={twoCol}>
        <div style={card}>
          <h3 style={h3}>Parcelas</h3>
          <div style={{ overflowY: "auto", maxHeight: "60vh" }}>
            <table style={table}>
              <thead>
                <tr>
                  <Th>Ações</Th>
                  <Th>Parcela</Th>
                  <Th>Árvores</Th>
                  <Th>Volume</Th>
                </tr>
              </thead>
              <tbody>
                {rows.map((r) => (
                  <tr key={r.id} style={{ ...trLine, ...(r.ativo ? activeRow : null) }}>
                    <Td>
                      <button style={smallBtn} onClick={() => toggleParcela(r.id)}>
                        {r.ativo ? "Desativar" : "Ativar"}
                      </button>
                    </Td>
                    <Td>{r.id}</Td>
                    <Td>{r.arvores}</Td>
                    <Td>{fmtNum(r.volume)}</Td>
                  </tr>
                ))}
                {rows.length === 0 && (
                  <tr><Td colSpan={4} style={{ color: "#6b7280" }}>Nenhuma parcela.</Td></tr>
                )}
              </tbody>
            </table>
          </div>
        </div>

        <div style={card}>
          <h3 style={h3}>Estatística de Amostragem (90%)</h3>
          <div style={statsGrid}>
            <table style={tableStats}>
              <tbody>
                <tr><TdLabel>Média do Volume</TdLabel><TdValue>{fmtNum(stats.media)}</TdValue></tr>
                <tr><TdLabel>Coeficiente de Variação (CV%)</TdLabel><TdValue>{fmtNum(stats.cv)}</TdValue></tr>
                <tr><TdLabel>Erro de Amostragem (90%)</TdLabel><TdValue>{fmtNum(stats.erro)}</TdValue></tr>
                <tr><TdLabel>Número de Parcelas</TdLabel><TdValue>{stats.nParcelas}</TdValue></tr>
                <tr><TdLabel>Nº de Parcelas Necessárias (≤ {TARGET_ERR}%)</TdLabel><TdValue>{stats.nNec}</TdValue></tr>
              </tbody>
            </table>

            <div style={chartBox}>
              <canvas ref={canvasRef} style={canvasStyle} />
              <div style={hint}>Curva local: erro(n) = z·CV%/√n; z=1,645 (90%). Linha laranja = alvo {TARGET_ERR}%.</div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}

// Estilos (Calibri)
const root = { display: "grid", gap: 16, fontFamily: "Calibri, Arial, sans-serif" };
const card = { background: "#fff", borderRadius: 12, padding: 16, boxShadow: "0 6px 20px rgba(0,0,0,0.08)" };
const headerGrid = { display: "grid", gap: 12, gridTemplateColumns: "repeat(3, minmax(0, 1fr))" };
const twoCol = { display: "grid", gap: 16, gridTemplateColumns: "20% 1fr" };
const h3 = { margin: 0, marginBottom: 10 };
const table = { width: "100%", borderCollapse: "collapse" };
const tableStats = { width: "100%", borderCollapse: "separate", borderSpacing: 0 };
const trLine = { borderBottom: "1px solid #f0f0f0" };
const activeRow = { background: "#e8f5e9" };
const smallBtn = { background: "#e5e5e5", color: "#2e4631", border: "none", borderRadius: 6, padding: "6px 12px", cursor: "pointer", fontFamily: "Calibri, Arial, sans-serif", fontWeight: 700 };
const statsGrid = { display: "grid", gap: 32, gridTemplateColumns: "320px 1fr", alignItems: "start" };
const chartBox = { width: "50%", minWidth: 360, height: 360, display: "grid", justifySelf: "start" };
const canvasStyle = { width: "100%", height: 340, border: "1px solid #f3f4f6", borderRadius: 8, background: "#fff" };

function Th({ children }) { return <th style={{ textAlign: "left", padding: "8px 6px", color: "#6b7280", fontSize: 12 }}>{children}</th>; }
function Td({ children, colSpan }) { return <td colSpan={colSpan} style={{ padding: "8px 6px" }}>{children}</td>; }
const TdLabel = ({ children }) => <td style={{ padding: "8px 10px", width: 280, color: "#374151" }}>{children}</td>;
const TdValue = ({ children }) => <td style={{ padding: "8px 10px", fontWeight: 700 }}>{children}</td>;
const hint = { marginTop: 8, fontSize: 12, color: "#6b7280" };
