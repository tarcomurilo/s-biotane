export default function InvVolumetria() {
  return (
    <div>
      <h1>Projeto — Volumetria</h1>
      {/* aqui fica o conteúdo da sub-página Projeto */}
    </div>
  );
}
