import React, { useMemo, useState } from "react";
import TopbarInventario from "../components/TopbarInventario";

import InvProj from "./inventario/invproj";
import InvAmostragem from "./inventario/invamostragem"; // crie este arquivo
import InvVolumetria from "./inventario/invvolumetria"; // crie este arquivo
import InvFitossociologia from "./inventario/invfitossociologia"; // crie este arquivo
import InvEstrutura from "./inventario/investrutura"; // crie este arquivo
import InvDistribuicao from "./inventario/invdistribuicao"; // crie este arquivo
import InvEcologia from "./inventario/invecologia"; // crie este arquivo


const PAGES = {
  invproj: InvProj,
  invamostragem: InvAmostragem,
  invvolumetria: InvVolumetria,
  invfitossociologia: InvFitossociologia, // crie este arquivo
  investrutura: InvEstrutura, // crie este arquivo
  invdistribuicao: InvDistribuicao, // crie este arquivo
  invecologia: InvEcologia, // crie este arquivo

};

export default function Inventario() {
  const [key, setKey] = useState(() => sessionStorage.getItem("inv_subpage") || "invproj");
  const Page = useMemo(() => PAGES[key] || PAGES.invproj, [key]);

  const onSelect = (k) => {
    setKey(k);
    sessionStorage.setItem("inv_subpage", k);
  };

  return (
    <div style={{ display: "grid", gridTemplateRows: "auto 1fr", height: "100%" }}>
      <TopbarInventario activeKey={key} onSelect={onSelect} />
      <div style={{ padding: 32, paddingTop: 72 }}>
        <Page />
      </div>
    </div>
  );
}
