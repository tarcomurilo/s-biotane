// src/pages/mapa.jsx
import React from 'react';
import MapPage from '../components/MapPage';

export default function Mapa() {
  return <MapPage />;
}
