export default function Config() {
  return <h1>Config funcionando!</h1>;
}