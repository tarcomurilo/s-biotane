import Topbar from "../components/Topbar";

export default function Orcamento() {
  return (
    <div>
      <Topbar />
      {/* Conteúdo específico da tela Orçamento */}
      <div style={{ padding: 32 }}>
        <h2>Orçamento</h2>
        {/* ...restante da tela... */}
      </div>
    </div>
  );
}