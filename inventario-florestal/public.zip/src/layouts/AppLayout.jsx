import Sidebar from "../components/Sidebar";
import { Outlet } from "react-router-dom";

export default function AppLayout() {
  return (
    <div>
      <Sidebar />
      <main style={{
        marginLeft: 190,
        marginTop: 0,   // agora não precisa reservar espaço para Topbar global
        minHeight: "90vh",
        maxHeight: "95vh",
        height:"90vh",
        background: "linear-gradient(135deg, #f7faf7 80%, #e5e5e5 100%)"
      }}>
        <Outlet />
      </main>
    </div>
  );
}